import ui
import logger
import model

# logger.write_data(ui.get_data())
# print(str(model.search_data()))
model.edit_data()
